
Drupal module: Variable Extra
=============================

Add-ons and tools for Variable module.

See:
https://drupal.org/project/variable_extra
https://drupal.org/project/variable

Created and maintained by Reyero.net, http://reyero.net
